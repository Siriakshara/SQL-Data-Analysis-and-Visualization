CREATE TABLE accidents_median(
vehicle_types VARCHAR(100),
severity INT
);